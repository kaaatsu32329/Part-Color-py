from setuptools import setup

setup(
    name='partcolor',
    version='1.0',
    description='画像や映像のパートカラー化',
    author='UCHIYAMA Katsu',
    author_email='katsu1112uchi@gmail.com',
    url='https://github.com/kaaatsu32329/Part-Color',
)